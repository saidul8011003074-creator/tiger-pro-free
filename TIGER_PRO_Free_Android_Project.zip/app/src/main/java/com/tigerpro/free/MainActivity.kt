package com.tigerpro.free

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF070D18)
private val Panel = Color(0xFF14233B)
private val Aqua = Color(0xFF38D9FF)
private val Amber = Color(0xFFFFC845)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TigerFreeApp() }
    }
}

@Composable
private fun TigerFreeApp() {
    var tab by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Aqua, secondary = Amber, background = Night, surface = Panel)) {
        Scaffold(
            containerColor = Night,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Home", "Practice", "Score", "About").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Text(when (item) { "Home" -> "⌂"; "Practice" -> "🎯"; "Score" -> "🏆"; else -> "ℹ" }) },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().background(Night).padding(padding).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("🐯 TIGER PRO", color = Amber, fontSize = 29.sp, fontWeight = FontWeight.Black)
                    Text("FREE CARROM COMPANION", color = Aqua, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                item {
                    when (tab) {
                        "Practice" -> PracticePage()
                        "Score" -> ScorePage()
                        "About" -> AboutPage()
                        else -> HomePage(onPractice = { tab = "Practice" }, onScore = { tab = "Score" })
                    }
                }
                item {
                    Text("Free companion tools • No automatic gameplay", color = Color.LightGray, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun PanelCard(title: String, body: String, action: String? = null, onClick: (() -> Unit)? = null) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(title, color = Amber, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(body, color = Color(0xFFD8E3F4), lineHeight = 21.sp)
            if (action != null && onClick != null) {
                Button(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text(action, color = Night, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun HomePage(onPractice: () -> Unit, onScore: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PanelCard("Welcome!", "TIGER PRO Free — Carrom Pool-এর জন্য প্র্যাকটিস ও ম্যাচ ট্র্যাকিং টুল।")
        PanelCard("Practice Tools", "Match timer, practice session এবং reset controls.", "OPEN PRACTICE", onPractice)
        PanelCard("Score Tracker", "নিজের প্র্যাকটিস স্কোর হাতে হাতে লিখে রাখো.", "OPEN SCORE", onScore)
        PanelCard("Game Help", "Carrom Pool তুমি নিজে খুলে খেলবে। এই অ্যাপ গেমে স্বয়ংক্রিয়ভাবে শট নেয় না।")
    }
}

@Composable
private fun PracticePage() {
    var minutes by remember { mutableIntStateOf(0) }
    var completed by remember { mutableIntStateOf(0) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PRACTICE", color = Aqua, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        PanelCard("Match Timer", "Elapsed practice time: $minutes minute(s)")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { minutes++ }, modifier = Modifier.weight(1f)) { Text("+1 MIN") }
            OutlinedButton(onClick = { minutes = 0 }, modifier = Modifier.weight(1f)) { Text("RESET") }
        }
        PanelCard("Practice Sessions", "Completed sessions: $completed")
        Button(onClick = { completed++ }, modifier = Modifier.fillMaxWidth()) { Text("COMPLETE SESSION") }
        OutlinedButton(onClick = { minutes = 0; completed = 0 }, modifier = Modifier.fillMaxWidth()) { Text("RESET ALL") }
    }
}

@Composable
private fun ScorePage() {
    var own by remember { mutableIntStateOf(0) }
    var opponent by remember { mutableIntStateOf(0) }
    Text("SCORE TRACKER", color = Aqua, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    PanelCard("Your Score", "$own")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { own++ }, modifier = Modifier.weight(1f)) { Text("+ YOUR SCORE") }
        OutlinedButton(onClick = { own = 0 }, modifier = Modifier.weight(1f)) { Text("RESET") }
    }
    Spacer(Modifier.height(12.dp))
    PanelCard("Other Player", "$opponent")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { opponent++ }, modifier = Modifier.weight(1f)) { Text("+ OTHER SCORE") }
        OutlinedButton(onClick = { opponent = 0 }, modifier = Modifier.weight(1f)) { Text("RESET") }
    }
    Spacer(Modifier.height(12.dp))
    OutlinedButton(onClick = { own = 0; opponent = 0 }, modifier = Modifier.fillMaxWidth()) { Text("RESET BOTH SCORES") }
}

@Composable
private fun AboutPage() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        PanelCard("About TIGER PRO Free", "একটি বিনামূল্যের Carrom companion app — practice timer, score tracker ও session counter।")
        PanelCard("Fair Play", "অ্যাপটি Carrom Pool-এ নিজে থেকে লগইন, শট, auto play বা ultra-fast gameplay করে না।")
        PanelCard("Privacy", "এই starter app কোনো account বা payment data সংগ্রহ করে না।")
    }
}
