# TIGER PRO Free — বাংলা নির্দেশিকা

এই প্রজেক্টে শুধু বিনামূল্যের Carrom companion tools আছে:
- Home screen
- Practice session counter
- Match timer (ম্যানুয়াল +১ মিনিট)
- Score tracker
- About / fair-play information

কোনো Shop, payment, login, admin panel বা online backend নেই। এটি গেমে নিজে থেকে লগইন বা auto-play করে না।

## APK পাওয়ার সহজ উপায় (ফোন থেকে)
1. ZIP extract করুন।
2. GitHub-এ নতুন repository তৈরি করুন।
3. Extract করা ফোল্ডারের ভেতরের সব ফাইল/ফোল্ডার upload করুন; `.github` ফোল্ডারও রাখতে হবে।
4. Commit করুন এবং repository-র Actions tab খুলুন।
5. `Build TIGER PRO Free APK` workflow শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
6. সফল হলে Artifacts থেকে `TIGER-PRO-Free-APK` ডাউনলোড করুন। ZIP extract করলে `app-debug.apk` পাবেন।

Build সফল হবে—এমন নিশ্চয়তা দেওয়া যাচ্ছে না; build error হলে Actions-এর error log দেখে সংশোধন লাগতে পারে। এই ZIP নিজে APK নয়, এটি APK বানানোর source project।
